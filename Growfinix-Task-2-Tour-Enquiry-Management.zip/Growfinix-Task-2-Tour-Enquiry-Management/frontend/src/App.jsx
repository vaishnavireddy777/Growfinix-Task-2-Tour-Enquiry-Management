import { useEffect, useMemo, useState } from "react";

const API = "http://localhost:5001/api/enquiries";

const emptyForm = {
  customer_name: "",
  email: "",
  phone: "",
  destination: "",
  travel_date: "",
  travellers: 1,
  message: "",
  status: "New"
};

function App() {
  const [enquiries, setEnquiries] = useState([]);
  const [form, setForm] = useState(emptyForm);
  const [editingId, setEditingId] = useState(null);
  const [search, setSearch] = useState("");
  const [message, setMessage] = useState("");

  const loadEnquiries = async () => {
    try {
      const res = await fetch(API);
      const data = await res.json();
      setEnquiries(data);
    } catch {
      setMessage("Could not connect to the backend.");
    }
  };

  useEffect(() => {
    loadEnquiries();
  }, []);

  const filtered = useMemo(() => {
    const q = search.toLowerCase();
    return enquiries.filter(e =>
      [e.customer_name, e.email, e.destination, e.status]
        .join(" ")
        .toLowerCase()
        .includes(q)
    );
  }, [enquiries, search]);

  const change = e => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const submit = async e => {
    e.preventDefault();
    setMessage("");

    if (!form.customer_name || !form.email || !form.destination) {
      setMessage("Please fill customer name, email and destination.");
      return;
    }

    const url = editingId ? `${API}/${editingId}` : API;
    const method = editingId ? "PUT" : "POST";

    try {
      const res = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form)
      });

      const data = await res.json();

      if (!res.ok) {
        setMessage(data.message || "Something went wrong.");
        return;
      }

      setForm(emptyForm);
      setEditingId(null);
      setMessage(editingId ? "Enquiry updated." : "Enquiry added.");
      loadEnquiries();
    } catch {
      setMessage("Could not connect to the backend.");
    }
  };

  const edit = enquiry => {
    setEditingId(enquiry.id);
    setForm({
      customer_name: enquiry.customer_name || "",
      email: enquiry.email || "",
      phone: enquiry.phone || "",
      destination: enquiry.destination || "",
      travel_date: enquiry.travel_date
        ? enquiry.travel_date.slice(0, 10)
        : "",
      travellers: enquiry.travellers || 1,
      message: enquiry.message || "",
      status: enquiry.status || "New"
    });
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const remove = async id => {
    if (!confirm("Delete this enquiry?")) return;

    await fetch(`${API}/${id}`, { method: "DELETE" });
    loadEnquiries();
  };

  const cancelEdit = () => {
    setEditingId(null);
    setForm(emptyForm);
    setMessage("");
  };

  return (
    <div className="min-h-screen bg-slate-50">
      <header className="bg-slate-900 text-white">
        <div className="mx-auto max-w-7xl px-5 py-8">
          <p className="text-sm font-semibold tracking-widest text-slate-300">
            GROWFINIX INTERNSHIP
          </p>
          <h1 className="mt-2 text-3xl font-bold">
            Tour Enquiry Management
          </h1>
          <p className="mt-2 text-slate-300">
            Manage customer tour enquiries in one place.
          </p>
        </div>
      </header>

      <main className="mx-auto max-w-7xl space-y-7 px-5 py-8">
        <section className="rounded-2xl bg-white p-6 shadow-sm">
          <div className="mb-5 flex items-center justify-between">
            <div>
              <h2 className="text-xl font-bold">
                {editingId ? "Edit Enquiry" : "New Enquiry"}
              </h2>
              <p className="text-sm text-slate-500">
                Add or update customer travel requirements.
              </p>
            </div>
            {editingId && (
              <button
                onClick={cancelEdit}
                className="rounded-lg border px-4 py-2 text-sm"
              >
                Cancel
              </button>
            )}
          </div>

          <form onSubmit={submit} className="grid gap-4 md:grid-cols-2">
            <input className="rounded-lg border p-3" name="customer_name"
              placeholder="Customer name" value={form.customer_name} onChange={change} />
            <input className="rounded-lg border p-3" name="email" type="email"
              placeholder="Email" value={form.email} onChange={change} />
            <input className="rounded-lg border p-3" name="phone"
              placeholder="Phone" value={form.phone} onChange={change} />
            <input className="rounded-lg border p-3" name="destination"
              placeholder="Destination" value={form.destination} onChange={change} />
            <input className="rounded-lg border p-3" name="travel_date" type="date"
              value={form.travel_date} onChange={change} />
            <input className="rounded-lg border p-3" name="travellers" type="number" min="1"
              value={form.travellers} onChange={change} />
            <select className="rounded-lg border p-3" name="status"
              value={form.status} onChange={change}>
              <option>New</option>
              <option>Contacted</option>
              <option>Confirmed</option>
              <option>Closed</option>
            </select>
            <input className="rounded-lg border p-3" name="message"
              placeholder="Message / requirements" value={form.message} onChange={change} />

            <button
              className="rounded-lg bg-slate-900 px-5 py-3 font-semibold text-white hover:bg-slate-800 md:col-span-2"
              type="submit"
            >
              {editingId ? "Update Enquiry" : "Add Enquiry"}
            </button>
          </form>

          {message && (
            <p className="mt-4 rounded-lg bg-slate-100 p-3 text-sm">
              {message}
            </p>
          )}
        </section>

        <section className="rounded-2xl bg-white p-6 shadow-sm">
          <div className="mb-5 flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
            <div>
              <h2 className="text-xl font-bold">All Enquiries</h2>
              <p className="text-sm text-slate-500">
                {filtered.length} enquiry/enquiries shown
              </p>
            </div>
            <input
              className="rounded-lg border p-3 md:w-80"
              placeholder="Search customer, destination..."
              value={search}
              onChange={e => setSearch(e.target.value)}
            />
          </div>

          <div className="overflow-x-auto">
            <table className="min-w-full text-left text-sm">
              <thead>
                <tr className="border-b text-slate-500">
                  <th className="p-3">Customer</th>
                  <th className="p-3">Destination</th>
                  <th className="p-3">Date</th>
                  <th className="p-3">Travellers</th>
                  <th className="p-3">Status</th>
                  <th className="p-3">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map(item => (
                  <tr key={item.id} className="border-b last:border-0">
                    <td className="p-3">
                      <div className="font-semibold">{item.customer_name}</div>
                      <div className="text-xs text-slate-500">{item.email}</div>
                    </td>
                    <td className="p-3">{item.destination}</td>
                    <td className="p-3">{item.travel_date ? item.travel_date.slice(0, 10) : "-"}</td>
                    <td className="p-3">{item.travellers}</td>
                    <td className="p-3">
                      <span className="rounded-full bg-slate-100 px-3 py-1 text-xs font-semibold">
                        {item.status}
                      </span>
                    </td>
                    <td className="p-3">
                      <div className="flex gap-2">
                        <button onClick={() => edit(item)}
                          className="rounded-lg border px-3 py-2 text-xs font-semibold">
                          Edit
                        </button>
                        <button onClick={() => remove(item.id)}
                          className="rounded-lg bg-red-600 px-3 py-2 text-xs font-semibold text-white">
                          Delete
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>

            {filtered.length === 0 && (
              <p className="py-10 text-center text-slate-500">
                No enquiries found.
              </p>
            )}
          </div>
        </section>
      </main>
    </div>
  );
}

export default App;
