# Growfinix Internship - Task 2
## Tour Enquiry Management Platform

A full-stack tour enquiry management platform created for the Growfinix Full Stack Development Internship.

### Features
- Add a tour enquiry
- View all enquiries
- Update enquiry status
- Edit enquiry details
- Delete enquiries
- Search enquiries
- Responsive React interface
- PostgreSQL database
- REST API with Express

### Tech Stack
- React
- Tailwind CSS
- Node.js
- Express.js
- PostgreSQL

### Project Structure
```text
Growfinix-Task-2-Tour-Enquiry-Management/
├── frontend/
└── backend/
```

### Backend Setup
1. Open the `backend` folder.
2. Run `npm install`.
3. Create a PostgreSQL database named `growfinix_tours`.
4. Run the SQL from `schema.sql`.
5. Copy `.env.example` to `.env` and update the database connection.
6. Run `npm run dev`.

### Frontend Setup
1. Open the `frontend` folder.
2. Run `npm install`.
3. Run `npm run dev`.

### REST API
- `GET /api/enquiries` - Get all enquiries
- `GET /api/enquiries/:id` - Get one enquiry
- `POST /api/enquiries` - Create enquiry
- `PUT /api/enquiries/:id` - Update enquiry
- `DELETE /api/enquiries/:id` - Delete enquiry

### Enquiry Fields
- Customer name
- Email
- Phone
- Destination
- Travel date
- Number of travellers
- Message
- Status

## Growfinix Internship
Task: Tour Enquiry Management Platform
