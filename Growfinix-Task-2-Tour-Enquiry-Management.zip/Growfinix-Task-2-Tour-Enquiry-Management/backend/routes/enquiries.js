const express = require("express");
const pool = require("../db/database");

const router = express.Router();

router.get("/", async (req, res) => {
  try {
    const result = await pool.query(
      "SELECT * FROM enquiries ORDER BY created_at DESC"
    );
    res.json(result.rows);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Failed to fetch enquiries" });
  }
});

router.get("/:id", async (req, res) => {
  try {
    const result = await pool.query(
      "SELECT * FROM enquiries WHERE id = $1",
      [req.params.id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ message: "Enquiry not found" });
    }

    res.json(result.rows[0]);
  } catch (error) {
    res.status(500).json({ message: "Failed to fetch enquiry" });
  }
});

router.post("/", async (req, res) => {
  try {
    const {
      customer_name,
      email,
      phone,
      destination,
      travel_date,
      travellers,
      message,
      status
    } = req.body;

    if (!customer_name || !email || !destination) {
      return res.status(400).json({
        message: "Customer name, email and destination are required"
      });
    }

    const result = await pool.query(
      `INSERT INTO enquiries
      (customer_name, email, phone, destination, travel_date, travellers, message, status)
      VALUES ($1,$2,$3,$4,$5,$6,$7,$8)
      RETURNING *`,
      [
        customer_name,
        email,
        phone || null,
        destination,
        travel_date || null,
        travellers || 1,
        message || null,
        status || "New"
      ]
    );

    res.status(201).json(result.rows[0]);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Failed to create enquiry" });
  }
});

router.put("/:id", async (req, res) => {
  try {
    const {
      customer_name,
      email,
      phone,
      destination,
      travel_date,
      travellers,
      message,
      status
    } = req.body;

    const result = await pool.query(
      `UPDATE enquiries
       SET customer_name=$1, email=$2, phone=$3, destination=$4,
           travel_date=$5, travellers=$6, message=$7, status=$8
       WHERE id=$9
       RETURNING *`,
      [
        customer_name,
        email,
        phone || null,
        destination,
        travel_date || null,
        travellers || 1,
        message || null,
        status || "New",
        req.params.id
      ]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ message: "Enquiry not found" });
    }

    res.json(result.rows[0]);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Failed to update enquiry" });
  }
});

router.delete("/:id", async (req, res) => {
  try {
    const result = await pool.query(
      "DELETE FROM enquiries WHERE id = $1 RETURNING id",
      [req.params.id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ message: "Enquiry not found" });
    }

    res.json({ message: "Enquiry deleted successfully" });
  } catch (error) {
    res.status(500).json({ message: "Failed to delete enquiry" });
  }
});

module.exports = router;
