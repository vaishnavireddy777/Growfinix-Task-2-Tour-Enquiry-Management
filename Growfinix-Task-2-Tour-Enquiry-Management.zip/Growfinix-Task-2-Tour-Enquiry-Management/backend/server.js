require("dotenv").config();

const express = require("express");
const cors = require("cors");
const enquiryRoutes = require("./routes/enquiries");

const app = express();

app.use(cors());
app.use(express.json());

app.get("/", (req, res) => {
  res.json({ message: "Growfinix Tour Enquiry API is running" });
});

app.get("/api/health", (req, res) => {
  res.json({ status: "OK" });
});

app.use("/api/enquiries", enquiryRoutes);

const PORT = process.env.PORT || 5001;

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
