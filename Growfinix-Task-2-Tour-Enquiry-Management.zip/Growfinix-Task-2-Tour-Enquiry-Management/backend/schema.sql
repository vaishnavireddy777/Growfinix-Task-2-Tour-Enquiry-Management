CREATE TABLE enquiries (
  id SERIAL PRIMARY KEY,
  customer_name VARCHAR(120) NOT NULL,
  email VARCHAR(150) NOT NULL,
  phone VARCHAR(30),
  destination VARCHAR(150) NOT NULL,
  travel_date DATE,
  travellers INTEGER DEFAULT 1,
  message TEXT,
  status VARCHAR(30) DEFAULT 'New',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO enquiries
(customer_name, email, phone, destination, travel_date, travellers, message, status)
VALUES
('Ananya Sharma', 'ananya@example.com', '9876543210', 'Goa', '2026-12-15', 2, 'Interested in a beach package.', 'New'),
('Rahul Kumar', 'rahul@example.com', '9876501234', 'Manali', '2027-01-10', 4, 'Need hotel and transport options.', 'Contacted');
